Chapter01 does not contains code files.

To get the most out of this course, a modern laptop or desktop computer is required, running an up-to-date version of either Windows, macOS, or Linux 
(preferably Ubuntu). 
About 4 GB of RAM memory is recommended at the minimum; more RAM is always welcome.
It is assumed that the reader has a reasonable knowledge of the 
operating system of their choice and is comfortable with installing programs and adding directories to a path.