class ForLoopEnhanced {
    public static void main(String[] args) {
	String[] stringArray = { "One", "Two", "Three" };
	for (String s: stringArray) {
    		System.out.println(s);
	}
    }
}