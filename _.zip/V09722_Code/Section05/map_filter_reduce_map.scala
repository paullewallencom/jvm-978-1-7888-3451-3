var a = List[Int](1, 2, 3)
var b = a.map((x: Int) => 2 * x)

println(b)